import SwiftUI
import UIKit

enum CarbInTheme {
    // Pixel Kitchen keeps playful display lettering on Latin scripts and lets
    // iOS shape the other supported scripts with their native system fonts.
    static let canvas = adaptive(light: rgb(0xFFF6D8), dark: rgb(0x211B27))
    static let loadingCanvas = adaptive(light: rgb(0xEC5C55), dark: rgb(0x663C51))
    static let surface = adaptive(light: rgb(0xFFFCF1), dark: rgb(0x332B39))
    static let ticket = adaptive(light: rgb(0xFFF2BB), dark: rgb(0x352D3B))
    static let inset = adaptive(light: rgb(0xFFE9A5), dark: rgb(0x443545))
    static let ink = adaptive(light: rgb(0x32202C), dark: rgb(0xFFF1DB))
    static let mutedInk = adaptive(light: rgb(0x6A4C50), dark: rgb(0xDBC9D1))
    static let basil = adaptive(light: rgb(0x17663C), dark: rgb(0xB9E8B0))
    static let basilAction = adaptive(light: rgb(0x237B49), dark: rgb(0x2A7A4E))
    static let basilSoft = adaptive(light: rgb(0xD9F4D6), dark: rgb(0x2A4A3B))
    static let tomato = adaptive(light: rgb(0xBA303D), dark: rgb(0xFFADB0))
    static let tomatoAction = adaptive(light: rgb(0xCD3D48), dark: rgb(0xC04B58))
    static let tomatoSoft = adaptive(light: rgb(0xFFEBDF), dark: rgb(0x493037))
    static let butter = adaptive(light: rgb(0xFFCA4C), dark: rgb(0xF4C35C))
    static let navy = adaptive(light: rgb(0x1C617D), dark: rgb(0x9BD3EC))
    static let line = adaptive(light: rgb(0x4B2A35), dark: rgb(0xB69BAD))
    static let actionInk = Color(red: 1, green: 0.973, blue: 0.914)

    @MainActor static var selectedLanguage: AppLanguage = .english

    @MainActor static func brand(_ style: UIFont.TextStyle, size: CGFloat) -> Font {
        let face = UIFont(name: "PixelifySans-Regular_Bold", size: size)
            ?? UIFont.systemFont(ofSize: size, weight: .black)
        return Font(UIFontMetrics(forTextStyle: style).scaledFont(for: face))
    }

    @MainActor static func display(_ style: UIFont.TextStyle, size: CGFloat) -> Font {
        let usesPixelFace: Bool
        switch selectedLanguage {
        case .english, .french, .filipino, .spanish, .portuguese, .hungarian:
            usesPixelFace = true
        default:
            usesPixelFace = false
        }
        if usesPixelFace { return brand(style, size: size) }
        let nativeFace = UIFont.systemFont(ofSize: size, weight: .bold)
        return Font(UIFontMetrics(forTextStyle: style).scaledFont(for: nativeFace))
    }

    @MainActor static func reading(_ style: UIFont.TextStyle, size: CGFloat, weight: UIFont.Weight = .regular) -> Font {
        let usesNunito: Bool
        switch selectedLanguage {
        case .english, .french, .filipino, .spanish, .portuguese, .hungarian:
            usesNunito = true
        default:
            usesNunito = false
        }
        let nunitoName = weight >= .bold ? "Nunito-Bold" : (weight >= .semibold ? "Nunito-SemiBold" : "Nunito-Regular")
        let face = (usesNunito ? UIFont(name: nunitoName, size: size) : nil)
            ?? UIFont.systemFont(ofSize: size, weight: weight)
        return Font(UIFontMetrics(forTextStyle: style).scaledFont(for: face))
    }

    private static func rgb(_ value: UInt32) -> (CGFloat, CGFloat, CGFloat) {
        (CGFloat((value >> 16) & 0xFF) / 255, CGFloat((value >> 8) & 0xFF) / 255, CGFloat(value & 0xFF) / 255)
    }

    // Compatibility names used by the existing feature code.
    static let elevatedSurface = inset
    static let moss = basil
    static let mossSoft = basilSoft
    static let terracotta = tomato
    static let amber = butter
    static let pine = basil
    static let oat = inset

    static func adaptive(light: (CGFloat, CGFloat, CGFloat), dark: (CGFloat, CGFloat, CGFloat)) -> Color {
        Color(
            uiColor: UIColor { traits in
                let value = traits.userInterfaceStyle == .dark ? dark : light
                return UIColor(red: value.0, green: value.1, blue: value.2, alpha: 1)
            }
        )
    }
}

struct CountertopBackdrop: View {
    var body: some View {
        Canvas { context, size in
            let spacing: CGFloat = 22
            for x in stride(from: CGFloat(11), through: size.width, by: spacing) {
                for y in stride(from: CGFloat(11), through: size.height, by: spacing) {
                    context.fill(
                        Path(ellipseIn: CGRect(x: x - 1.1, y: y - 1.1, width: 2.2, height: 2.2)),
                        with: .color(CarbInTheme.butter.opacity(0.35))
                    )
                }
            }
        }
        .background(CarbInTheme.canvas)
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct CheckerboardSurface: View {
    var body: some View {
        Canvas { context, size in
            let tile: CGFloat = 23
            for column in 0...Int(ceil(size.width / tile)) {
                for row in 0...Int(ceil(size.height / tile)) where (column + row).isMultiple(of: 2) {
                    context.fill(
                        Path(CGRect(x: CGFloat(column) * tile, y: CGFloat(row) * tile, width: tile, height: tile)),
                        with: .color(CarbInTheme.butter.opacity(0.22))
                    )
                }
            }
        }
        .background(CarbInTheme.ticket)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct PrimaryActionStyle: ButtonStyle {
    var isEnabled = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(CarbInTheme.display(.headline, size: 17))
            .foregroundStyle(isEnabled ? CarbInTheme.actionInk : CarbInTheme.mutedInk)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 54)
            .padding(.horizontal, 18)
            .background {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(isEnabled ? CarbInTheme.tomatoAction : CarbInTheme.inset)
                    .shadow(color: CarbInTheme.ink.opacity(isEnabled ? 0.35 : 0.16), radius: 0, x: 0, y: configuration.isPressed ? 1 : 4)
            }
            .overlay {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .stroke(CarbInTheme.line, lineWidth: 3)
            }
            .offset(y: configuration.isPressed ? 3 : 0)
            .opacity(configuration.isPressed ? 0.92 : 1)
    }
}

struct SecondaryActionStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(CarbInTheme.display(.headline, size: 17))
            .foregroundStyle(CarbInTheme.ink)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 52)
            .padding(.horizontal, 18)
            .background {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(CarbInTheme.surface)
                    .shadow(color: CarbInTheme.ink.opacity(0.22), radius: 0, x: 0, y: configuration.isPressed ? 1 : 3)
            }
            .overlay {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .stroke(CarbInTheme.line, lineWidth: 3)
            }
            .offset(y: configuration.isPressed ? 2 : 0)
            .opacity(configuration.isPressed ? 0.74 : 1)
    }
}

struct CompactActionStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(CarbInTheme.ink)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 46)
            .padding(.horizontal, 12)
            .background {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(CarbInTheme.ticket)
                    .shadow(color: CarbInTheme.ink.opacity(0.16), radius: 0, x: 0, y: configuration.isPressed ? 0 : 2)
            }
            .overlay {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .stroke(CarbInTheme.line.opacity(0.90), lineWidth: 1.5)
            }
            .opacity(configuration.isPressed ? 0.70 : 1)
    }
}

struct MealPlateGraphic: View {
    var showsPen = false

    var body: some View {
        MealMirrorBadge()
            .accessibilityHidden(true)
    }
}

struct MealMirrorBadge: View {
    var showsStars = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var steamIsBright = false

    var body: some View {
        GeometryReader { geometry in
            let side = min(geometry.size.width, geometry.size.height)
            ZStack {
                Canvas { context, size in
                    let pixel = max(7, side / 14)
                    for row in 0...Int(ceil(size.height / pixel)) {
                        for column in 0...Int(ceil(size.width / pixel)) {
                            let color = (row + column).isMultiple(of: 2)
                                ? Color(red: 1, green: 0.88, blue: 0.48)
                                : Color(red: 1, green: 0.77, blue: 0.28)
                            context.fill(
                                Path(CGRect(x: CGFloat(column) * pixel, y: CGFloat(row) * pixel, width: pixel, height: pixel)),
                                with: .color(color)
                            )
                        }
                    }
                }
                .clipShape(Circle())
                .overlay { Circle().stroke(CarbInTheme.line, lineWidth: max(2, side * 0.025)) }
                .shadow(color: CarbInTheme.ink.opacity(0.26), radius: 0, x: 0, y: max(2, side * 0.025))
                .frame(width: side * 0.94, height: side * 0.94)

                Image("CurryMarkCutout")
                    .resizable()
                    .interpolation(.none)
                    .scaledToFit()
                    .frame(width: side, height: side)

                if side >= 120 {
                    SteamPixelHighlight()
                        .frame(width: side, height: side)
                        .opacity(reduceMotion ? 0.5 : (steamIsBright ? 0.72 : 0.25))
                        .animation(
                            reduceMotion ? nil : .easeInOut(duration: 2.8).repeatForever(autoreverses: true),
                            value: steamIsBright
                        )
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }

                if showsStars && side >= 100 {
                    PixelStar()
                        .frame(width: side * 0.075, height: side * 0.075)
                        .offset(x: -side * 0.42, y: -side * 0.35)
                    PixelStar()
                        .frame(width: side * 0.055, height: side * 0.055)
                        .offset(x: side * 0.42, y: -side * 0.25)
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .accessibilityHidden(true)
        .onAppear { steamIsBright = !reduceMotion }
        .onChange(of: reduceMotion) { _, newValue in steamIsBright = !newValue }
    }
}

private struct SteamPixelHighlight: View {
    // These small glints sit inside the three steam wisps of CurryMarkCutout.
    // Keeping them square preserves the original pixel art at large badge sizes.
    private let pixels: [(CGFloat, CGFloat, CGFloat)] = [
        (0.357, 0.102, 0.013), (0.370, 0.153, 0.011),
        (0.495, 0.040, 0.014), (0.485, 0.121, 0.011),
        (0.628, 0.126, 0.013), (0.615, 0.188, 0.011)
    ]

    var body: some View {
        Canvas { context, size in
            let side = min(size.width, size.height)
            for (x, y, width) in pixels {
                context.fill(
                    Path(CGRect(x: x * side, y: y * side, width: width * side, height: width * side)),
                    with: .color(.white)
                )
            }
        }
    }
}

private struct PixelStar: View {
    var body: some View {
        GeometryReader { geometry in
            let unit = geometry.size.width / 5
            ZStack {
                Rectangle().fill(CarbInTheme.line)
                    .frame(width: unit * 1.8, height: geometry.size.height)
                Rectangle().fill(CarbInTheme.line)
                    .frame(width: geometry.size.width, height: unit * 1.8)
                Rectangle().fill(CarbInTheme.surface)
                    .frame(width: unit, height: geometry.size.height)
                Rectangle().fill(CarbInTheme.surface)
                    .frame(width: geometry.size.width, height: unit)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .accessibilityHidden(true)
    }
}

private enum PixelFoodKind: Int, CaseIterable {
    case tomato, carrot, broccoli, rice, egg, fish

    // Hand-plotted 12 × 12 sprites. At the 36 pt ring size each square is
    // exactly 3 pt, keeping the food crisp on both 2× and 3× displays.
    var rows: [String] {
        switch self {
        case .tomato:
            ["....gGGg....", "...ggGGgg...", "...kggggk...", "..krrrrrrk..",
             ".kRrRrrrrRk.", ".kRrhrrrrRk.", "kRrhhrrrrrRk", "kRrrrrrrrrRk",
             ".kRrrrrrrRk.", ".kRrrrrrrRk.", "..kRRRRRRk..", "...kkkkkk..."]
        case .carrot:
            ["...g.g.g....", "..gGgGgGg...", "...gGGGg....", "....gGg.....",
             "...kkkkkk...", "..kOoOoOok..", "..koooooOk..", "...kooooOk..",
             "....koooOk..", ".....kooOk..", "......kook..", ".......kk..."]
        case .broccoli:
            ["...kk..kk...", "..kGgkkGgk..", ".kGgGGgGGgk.", "kGgGGgGGGgGk",
             "kggGGGGGGggk", ".kggGGGGggk.", "..kkgGGgkk..", "...kggggk...",
             "....kttk....", "...kttttk...", "...kttttk...", "....kkkk...."]
        case .rice:
            [".....kkkk...", "...kkwwwwkk.", "..kwwWwwWwwk", ".kwwwwwwwwk.",
             "kwwWwwwWwwwk", ".kkkkkkkkkk.", ".kbbbbbbbbk.", "..kBbbbbBk..",
             "...kBBBBk...", "....kkkk....", "............", "............"]
        case .egg:
            ["............", "..kkk.......", ".kwwWkkk....", "kwwwwwwwkk..",
             "kwwwyyywwwk.", "kwwyYYYywwk.", ".kwwYhYywwk.", "..kwwyyywwwk",
             "...kwwwwwwk.", "....kkkkkk..", "............", "............"]
        case .fish:
            [".....kk...kk", "....kUUk.kUk", "..kkUuUUkkUk", ".kUUuuuuUUk.",
            "kUekUuuuuUUk", "kUuuUuuuuUUk", ".kUUuuuuUUk.", "..kkUuUUkkUk",
             "....kUUk.kUk", ".....kk...kk", "............", "............"]
        }
    }
}

private struct PixelFoodGlyph: View {
    let kind: PixelFoodKind

    var body: some View {
        Canvas { context, size in
            let rows = kind.rows
            let pixel = min(size.width, size.height) / 12
            for (y, row) in rows.enumerated() {
                for (x, symbol) in row.enumerated() where symbol != "." {
                    context.fill(
                        Path(CGRect(x: CGFloat(x) * pixel, y: CGFloat(y) * pixel, width: pixel, height: pixel)),
                        with: .color(color(for: symbol))
                    )
                }
            }
        }
        .accessibilityHidden(true)
    }

    private func color(for symbol: Character) -> Color {
        switch symbol {
        case "k": Color(red: 0.196, green: 0.118, blue: 0.165)
        case "g": Color(red: 0.094, green: 0.459, blue: 0.247)
        case "G": Color(red: 0.333, green: 0.733, blue: 0.369)
        case "r": Color(red: 0.902, green: 0.271, blue: 0.306)
        case "R": Color(red: 0.686, green: 0.184, blue: 0.227)
        case "h": Color(red: 1.000, green: 0.969, blue: 0.769)
        case "o": Color(red: 0.961, green: 0.498, blue: 0.161)
        case "O": Color(red: 1.000, green: 0.682, blue: 0.243)
        case "t": Color(red: 0.573, green: 0.733, blue: 0.388)
        case "w": Color(red: 1.000, green: 0.980, blue: 0.898)
        case "W": Color(red: 0.871, green: 0.820, blue: 0.686)
        case "b": Color(red: 0.886, green: 0.361, blue: 0.353)
        case "B": Color(red: 0.616, green: 0.216, blue: 0.255)
        case "y": Color(red: 0.929, green: 0.620, blue: 0.125)
        case "Y": Color(red: 1.000, green: 0.796, blue: 0.243)
        case "u": Color(red: 0.196, green: 0.510, blue: 0.651)
        case "U": Color(red: 0.380, green: 0.725, blue: 0.780)
        case "e": Color(red: 1.000, green: 1.000, blue: 1.000)
        default: .clear
        }
    }
}

struct FoodOrbitRing: View {
    var diameter: CGFloat = 286
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isRotating = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(CarbInTheme.actionInk.opacity(0.85), style: StrokeStyle(lineWidth: 3, dash: [8, 9]))
                .frame(width: diameter - 10, height: diameter - 10)

            MealMirrorBadge()
                .frame(width: diameter * 0.76, height: diameter * 0.76)

            ZStack {
                ForEach(PixelFoodKind.allCases, id: \.rawValue) { food in
                    let angle = Double(food.rawValue) * 2 * Double.pi / Double(PixelFoodKind.allCases.count)
                    PixelFoodGlyph(kind: food)
                        .frame(width: 36, height: 36)
                        .padding(3)
                        .background(CarbInTheme.actionInk, in: Circle())
                        .overlay {
                            Circle().stroke(Color(red: 0.196, green: 0.118, blue: 0.165), lineWidth: 2)
                        }
                        .rotationEffect(.degrees(isRotating && !reduceMotion ? -360 : 0))
                        .offset(x: CGFloat(cos(angle)) * (diameter / 2 - 5), y: CGFloat(sin(angle)) * (diameter / 2 - 5))
                }
            }
            .frame(width: diameter, height: diameter)
            .rotationEffect(.degrees(isRotating && !reduceMotion ? 360 : 0))
            .animation(reduceMotion ? nil : .linear(duration: 14).repeatForever(autoreverses: false), value: isRotating)
        }
        .frame(width: diameter, height: diameter)
        .onAppear { isRotating = !reduceMotion }
        .onChange(of: reduceMotion) { _, newValue in isRotating = !newValue }
        .accessibilityHidden(true)
    }
}

struct KitchenLoadingArtwork: View {
    let diameter: CGFloat

    var body: some View {
        FoodOrbitRing(diameter: diameter)
            .frame(width: diameter, height: diameter)
            .accessibilityHidden(true)
    }
}

struct PixelCornerFrame: View {
    var color: Color = CarbInTheme.tomato
    var inset: CGFloat = 10
    var arm: CGFloat = 16
    var thickness: CGFloat = 3

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                pixelCorner
                Spacer(minLength: 0)
                pixelCorner.rotationEffect(.degrees(90))
            }
            Spacer(minLength: 0)
            HStack(spacing: 0) {
                pixelCorner.rotationEffect(.degrees(270))
                Spacer(minLength: 0)
                pixelCorner.rotationEffect(.degrees(180))
            }
        }
        .padding(inset)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private var pixelCorner: some View {
        ZStack(alignment: .topLeading) {
            Rectangle().fill(color).frame(width: arm, height: thickness)
            Rectangle().fill(color).frame(width: thickness, height: arm)
        }
    }
}

struct PixelDivider: View {
    var color: Color = CarbInTheme.tomato

    var body: some View {
        HStack(spacing: 3) {
            ForEach(0..<15, id: \.self) { index in
                Rectangle()
                    .fill(index.isMultiple(of: 4) ? color : CarbInTheme.line.opacity(0.55))
                    .frame(width: index.isMultiple(of: 4) ? 11 : 5, height: 3)
            }
        }
        .frame(maxWidth: 210, alignment: .leading)
        .accessibilityHidden(true)
    }
}

struct StepRail: View {
    let current: Int
    @EnvironmentObject private var localization: LocalizationStore

    var body: some View {
        HStack(spacing: 6) {
            ForEach(1...3, id: \.self) { step in
                Rectangle()
                    .fill(step < current ? CarbInTheme.basilAction :
                          (step == current ? CarbInTheme.tomatoAction : CarbInTheme.inset))
                    .frame(maxWidth: .infinity, minHeight: 7, maxHeight: 7)
                    .overlay { Rectangle().stroke(CarbInTheme.line.opacity(0.6), lineWidth: 1) }
            }
            Text(verbatim: "\(current)/3")
                .font(CarbInTheme.brand(.caption1, size: 13))
                .foregroundStyle(CarbInTheme.ink)
                .fixedSize()
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(localization.text(["STEP 1 OF 3", "STEP 2 OF 3", "STEP 3 OF 3"][max(0, min(current - 1, 2))]))
    }
}

struct SafetyRail: View {
    let title: LocalizedStringKey
    let detail: LocalizedStringKey
    var symbol = "exclamationmark.shield.fill"

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Rectangle()
                .fill(CarbInTheme.tomato)
                .frame(width: 5)
            Image(systemName: symbol)
                .foregroundStyle(CarbInTheme.tomato)
                .frame(width: 24, height: 24)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(CarbInTheme.display(.subheadline, size: 15))
                    .foregroundStyle(CarbInTheme.ink)
                Text(detail)
                    .font(.footnote)
                    .foregroundStyle(CarbInTheme.mutedInk)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 12)
        .padding(.trailing, 12)
        .background(CarbInTheme.ticket)
            .overlay { Rectangle().stroke(CarbInTheme.ink.opacity(0.78), lineWidth: 2) }
    }
}

private struct TicketEdge: View {
    var body: some View {
        HStack(spacing: 0) {
            ForEach(0..<42, id: \.self) { index in
                Rectangle()
                    .fill(index % 3 == 0 ? CarbInTheme.tomatoAction :
                          (index % 3 == 1 ? CarbInTheme.butter : CarbInTheme.basilAction))
                    .frame(maxWidth: .infinity, minHeight: 4, maxHeight: 4)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 10)
        .clipped()
        .accessibilityHidden(true)
    }
}

private struct KitchenBubbleShape: Shape {
    let tailOnTrailing: Bool

    func path(in rect: CGRect) -> Path {
        let left = rect.minX + 2
        let right = rect.maxX - 2
        let top = rect.minY + 2
        let bottom = rect.maxY - 16
        let radius = min(10, (right - left) / 8, (bottom - top) / 8)
        let center = tailOnTrailing ? right - 43 : left + 43
        let tailLeft = center - 14
        let tailRight = center + 14

        return Path { path in
            path.move(to: CGPoint(x: left + radius, y: top))
            path.addLine(to: CGPoint(x: right - radius, y: top))
            path.addQuadCurve(to: CGPoint(x: right, y: top + radius), control: CGPoint(x: right, y: top))
            path.addLine(to: CGPoint(x: right, y: bottom - radius))
            path.addQuadCurve(to: CGPoint(x: right - radius, y: bottom), control: CGPoint(x: right, y: bottom))
            path.addLine(to: CGPoint(x: tailRight, y: bottom))
            path.addLine(to: CGPoint(x: center, y: rect.maxY - 2))
            path.addLine(to: CGPoint(x: tailLeft, y: bottom))
            path.addLine(to: CGPoint(x: left + radius, y: bottom))
            path.addQuadCurve(to: CGPoint(x: left, y: bottom - radius), control: CGPoint(x: left, y: bottom))
            path.addLine(to: CGPoint(x: left, y: top + radius))
            path.addQuadCurve(to: CGPoint(x: left + radius, y: top), control: CGPoint(x: left, y: top))
            path.closeSubpath()
        }
    }
}

private struct KitchenBubbleSurface: ViewModifier {
    let inset: CGFloat

    func body(content: Content) -> some View {
        // SwiftUI mirrors Shape paths for right-to-left layout automatically.
        let shape = KitchenBubbleShape(tailOnTrailing: false)
        content
            .padding(.horizontal, inset)
            .padding(.top, inset)
            .padding(.bottom, inset + 14)
            .background {
                shape.fill(CarbInTheme.surface)
                    .shadow(color: CarbInTheme.ink.opacity(0.16), radius: 0, x: 0, y: 4)
            }
            .overlay { shape.stroke(CarbInTheme.line, lineWidth: 3) }
    }
}

private struct KitchenNavigationTitle: ViewModifier {
    let title: LocalizedStringKey
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    func body(content: Content) -> some View {
        content.navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text(title)
                        // Every screen also has a full-size heading in its body.
                        // Keep the compact navigation cue readable at AX sizes.
                        .font(dynamicTypeSize.isAccessibilitySize
                            ? .system(size: 18, weight: .bold)
                            : CarbInTheme.display(.headline, size: 18))
                        .foregroundStyle(CarbInTheme.ink)
                        .lineLimit(dynamicTypeSize.isAccessibilitySize ? 1 : 2)
                        .minimumScaleFactor(0.8)
                }
            }
            .toolbarBackground(CarbInTheme.canvas, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
    }
}

extension View {
    func kitchenNavigationTitle(_ title: LocalizedStringKey) -> some View {
        modifier(KitchenNavigationTitle(title: title))
    }

    func kitchenBubble(inset: CGFloat = 18) -> some View {
        modifier(KitchenBubbleSurface(inset: inset))
    }

    func workbenchSurface(inset: CGFloat = 18, fill: Color = CarbInTheme.surface) -> some View {
        self.padding(inset)
            .background {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(fill)
                    .shadow(color: CarbInTheme.line.opacity(0.48), radius: 0, x: 4, y: 5)
            }
            .overlay {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .stroke(CarbInTheme.line, lineWidth: 3)
            }
    }

    func mealTicket(inset: CGFloat = 18) -> some View {
        self.padding(inset)
            .background {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(CarbInTheme.surface)
                    .shadow(color: CarbInTheme.line.opacity(0.48), radius: 0, x: 4, y: 5)
            }
            .overlay(alignment: .top) { TicketEdge() }
            .overlay {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .stroke(CarbInTheme.line, lineWidth: 3)
            }
    }

    func insetControlGroup(inset: CGFloat = 14) -> some View {
        self.padding(inset)
            .background(CarbInTheme.butter.opacity(0.20), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .stroke(CarbInTheme.line.opacity(0.72), lineWidth: 1.5)
            }
    }

    // Legacy call sites now receive the distinctive ticket surface rather than
    // the former universal 24-point floating card.
    func mirrorCard(inset: CGFloat = 18) -> some View {
        mealTicket(inset: inset)
    }

    func pixelCorners(color: Color = CarbInTheme.tomato, inset: CGFloat = 10) -> some View {
        overlay { PixelCornerFrame(color: color, inset: inset) }
    }
}
