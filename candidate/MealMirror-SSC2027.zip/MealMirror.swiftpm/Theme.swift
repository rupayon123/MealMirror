import SwiftUI
import UIKit

enum CarbInTheme {
    // Pixel Kitchen keeps playful display lettering on Latin scripts and lets
    // iOS shape the other supported scripts with their native system fonts.
    static let canvas = adaptive(light: rgb(0xFFF6D8), dark: rgb(0x211B27))
    static let loadingCanvas = adaptive(light: rgb(0xEC5C55), dark: rgb(0x663C51))
    static let surface = adaptive(light: rgb(0xFFFCF1), dark: rgb(0x332B39))
    static let ticket = adaptive(light: rgb(0xFFF2BB), dark: rgb(0x352D3B))
    static let inset = adaptive(light: rgb(0xFFE9A5), dark: rgb(0x443545))
    static let ink = adaptive(light: rgb(0x32202C), dark: rgb(0xFFF1DB))
    @MainActor static func navigationInk(for scheme: ColorScheme) -> Color {
        // A dismissed sheet can leave the toolbar's SwiftUI color-scheme
        // environment out of sync with the window for a scrolled screen.
        // Use the active scene so the title matches the canvas beneath it.
        let style = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first(where: { $0.activationState == .foregroundActive })?
            .traitCollection.userInterfaceStyle
        let isDark = switch style {
        case .dark: true
        case .light: false
        default: scheme == .dark
        }
        let value = isDark ? rgb(0xFFF1DB) : rgb(0x32202C)
        return Color(red: value.0, green: value.1, blue: value.2)
    }
    static let mutedInk = adaptive(light: rgb(0x6A4C50), dark: rgb(0xDBC9D1))
    static let basil = adaptive(light: rgb(0x17663C), dark: rgb(0xB9E8B0))
    static let basilAction = adaptive(light: rgb(0x237B49), dark: rgb(0x2A7A4E))
    static let basilSoft = adaptive(light: rgb(0xD9F4D6), dark: rgb(0x2A4A3B))
    static let tomato = adaptive(light: rgb(0xBA303D), dark: rgb(0xFFADB0))
    static let tomatoAction = adaptive(light: rgb(0xCD3D48), dark: rgb(0xC04B58))
    static let tomatoSoft = adaptive(light: rgb(0xFFEBDF), dark: rgb(0x493037))
    static let butter = adaptive(light: rgb(0xFFCA4C), dark: rgb(0xF4C35C))
    static let navy = adaptive(light: rgb(0x1C617D), dark: rgb(0x9BD3EC))
    static let line = adaptive(light: rgb(0x4B2A35), dark: rgb(0xB69BAD))
    static let actionInk = Color(red: 1, green: 0.973, blue: 0.914)

    @MainActor static var selectedLanguage: AppLanguage = .english

    @MainActor static func brand(_ style: UIFont.TextStyle, size: CGFloat) -> Font {
        let face = UIFont(name: "PixelifySans-Regular_Bold", size: size)
            ?? UIFont.systemFont(ofSize: size, weight: .black)
        return Font(UIFontMetrics(forTextStyle: style).scaledFont(for: face))
    }

    @MainActor static func display(_ style: UIFont.TextStyle, size: CGFloat) -> Font {
        let usesPixelFace: Bool
        switch selectedLanguage {
        case .english, .french, .filipino, .spanish, .portuguese, .hungarian:
            usesPixelFace = true
        default:
            usesPixelFace = false
        }
        if usesPixelFace { return brand(style, size: size) }
        let nativeFace = UIFont.systemFont(ofSize: size, weight: .bold)
        return Font(UIFontMetrics(forTextStyle: style).scaledFont(for: nativeFace))
    }

    @MainActor static func reading(_ style: UIFont.TextStyle, size: CGFloat, weight: UIFont.Weight = .regular) -> Font {
        let usesNunito: Bool
        switch selectedLanguage {
        case .english, .french, .filipino, .spanish, .portuguese, .hungarian:
            usesNunito = true
        default:
            usesNunito = false
        }
        let nunitoName = weight >= .bold ? "Nunito-Bold" : (weight >= .semibold ? "Nunito-SemiBold" : "Nunito-Regular")
        let face = (usesNunito ? UIFont(name: nunitoName, size: size) : nil)
            ?? UIFont.systemFont(ofSize: size, weight: weight)
        return Font(UIFontMetrics(forTextStyle: style).scaledFont(for: face))
    }

    private static func rgb(_ value: UInt32) -> (CGFloat, CGFloat, CGFloat) {
        (CGFloat((value >> 16) & 0xFF) / 255, CGFloat((value >> 8) & 0xFF) / 255, CGFloat(value & 0xFF) / 255)
    }

    // Compatibility names used by the existing feature code.
    static let elevatedSurface = inset
    static let moss = basil
    static let mossSoft = basilSoft
    static let terracotta = tomato
    static let amber = butter
    static let pine = basil
    static let oat = inset

    static func adaptive(light: (CGFloat, CGFloat, CGFloat), dark: (CGFloat, CGFloat, CGFloat)) -> Color {
        Color(
            uiColor: UIColor { traits in
                let value = traits.userInterfaceStyle == .dark ? dark : light
                return UIColor(red: value.0, green: value.1, blue: value.2, alpha: 1)
            }
        )
    }
}

// The same three-step silhouette at four visible sizes across the journey.
enum PixelSurfaceTier {
    static let panel: CGFloat = 30
    static let card: CGFloat = 24
    static let field: CGFloat = 18
    static let chip: CGFloat = 15
}

// A continuous stepped outline shared by cards, controls and photo frames.
// Insets move every edge together so strokeBorder stays closed at each corner.
struct PixelRoundedRectangle: InsettableShape {
    var cornerRadius: CGFloat = PixelSurfaceTier.panel
    private var insetAmount: CGFloat = 0

    init(cornerRadius: CGFloat = PixelSurfaceTier.panel) { self.cornerRadius = cornerRadius }

    func inset(by amount: CGFloat) -> Self {
        var copy = self
        copy.insetAmount += amount
        return copy
    }

    func path(in rect: CGRect) -> Path {
        let box = rect.insetBy(dx: insetAmount, dy: insetAmount)
        guard box.width > 0, box.height > 0 else { return Path() }
        let u = min(max(0, floor((cornerRadius - insetAmount) / 3)), min(box.width, box.height) / 4)
        let x = box.minX, y = box.minY, right = box.maxX, bottom = box.maxY
        return Path { path in
            path.move(to: CGPoint(x: x + 2 * u, y: y))
            for point in [
                CGPoint(x: right - 2 * u, y: y),
                CGPoint(x: right - 2 * u, y: y + u),
                CGPoint(x: right - u, y: y + u),
                CGPoint(x: right - u, y: y + 2 * u),
                CGPoint(x: right, y: y + 2 * u),
                CGPoint(x: right, y: bottom - 2 * u),
                CGPoint(x: right - u, y: bottom - 2 * u),
                CGPoint(x: right - u, y: bottom - u),
                CGPoint(x: right - 2 * u, y: bottom - u),
                CGPoint(x: right - 2 * u, y: bottom),
                CGPoint(x: x + 2 * u, y: bottom),
                CGPoint(x: x + 2 * u, y: bottom - u),
                CGPoint(x: x + u, y: bottom - u),
                CGPoint(x: x + u, y: bottom - 2 * u),
                CGPoint(x: x, y: bottom - 2 * u),
                CGPoint(x: x, y: y + 2 * u),
                CGPoint(x: x + u, y: y + 2 * u),
                CGPoint(x: x + u, y: y + u),
                CGPoint(x: x + 2 * u, y: y + u)
            ] { path.addLine(to: point) }
            path.closeSubpath()
        }
    }
}

struct CountertopBackdrop: View {
    var body: some View {
        Canvas { context, size in
            let spacing: CGFloat = 22
            for x in stride(from: CGFloat(11), through: size.width, by: spacing) {
                for y in stride(from: CGFloat(11), through: size.height, by: spacing) {
                    context.fill(
                        Path(ellipseIn: CGRect(x: x - 1.1, y: y - 1.1, width: 2.2, height: 2.2)),
                        with: .color(CarbInTheme.butter.opacity(0.35))
                    )
                }
            }
        }
        .background(CarbInTheme.canvas)
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct CheckerboardSurface: View {
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        Canvas { context, size in
            let tile: CGFloat = 23
            for column in 0...Int(ceil(size.width / tile)) {
                for row in 0...Int(ceil(size.height / tile)) where (column + row).isMultiple(of: 2) {
                    context.fill(
                        Path(CGRect(x: CGFloat(column) * tile, y: CGFloat(row) * tile, width: tile, height: tile)),
                        with: .color(CarbInTheme.butter.opacity(colorScheme == .dark ? 0.06 : 0.22))
                    )
                }
            }
        }
        .background(CarbInTheme.ticket)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct PrimaryActionStyle: ButtonStyle {
    var isEnabled = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(CarbInTheme.display(.headline, size: 17))
            .foregroundStyle(isEnabled ? CarbInTheme.actionInk : CarbInTheme.mutedInk)
            .fixedSize(horizontal: false, vertical: true)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 54)
            .padding(.horizontal, 18)
            .background {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card)
                    .fill(isEnabled ? CarbInTheme.tomatoAction : CarbInTheme.inset)
                    .shadow(color: CarbInTheme.ink.opacity(isEnabled ? 0.35 : 0.16), radius: 0, x: 0, y: configuration.isPressed ? 1 : 4)
            }
            .overlay {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card)
                    .strokeBorder(CarbInTheme.line, lineWidth: 3)
            }
            .offset(y: configuration.isPressed ? 3 : 0)
            .opacity(configuration.isPressed ? 0.92 : 1)
    }
}

struct SecondaryActionStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(CarbInTheme.display(.headline, size: 17))
            .foregroundStyle(CarbInTheme.ink)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 52)
            .padding(.horizontal, 18)
            .background {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card)
                    .fill(CarbInTheme.surface)
                    .shadow(color: CarbInTheme.ink.opacity(0.22), radius: 0, x: 0, y: configuration.isPressed ? 1 : 3)
            }
            .overlay {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card)
                    .strokeBorder(CarbInTheme.line, lineWidth: 3)
            }
            .offset(y: configuration.isPressed ? 2 : 0)
            .opacity(configuration.isPressed ? 0.74 : 1)
    }
}

struct CompactActionStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(CarbInTheme.reading(.subheadline, size: 15, weight: .semibold))
            .foregroundStyle(CarbInTheme.ink)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 46)
            .padding(.horizontal, 12)
            .background {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card)
                    .fill(CarbInTheme.ticket)
                    .shadow(color: CarbInTheme.ink.opacity(0.16), radius: 0, x: 0, y: configuration.isPressed ? 0 : 2)
            }
            .overlay {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card)
                    .strokeBorder(CarbInTheme.line.opacity(0.90), lineWidth: 1.5)
            }
            .opacity(configuration.isPressed ? 0.70 : 1)
    }
}

// Two independently accessible controls share one surface. The separator
// belongs to the tray, never to either icon or its tappable label.
struct PixelPhotoSourceTray<First: View, Second: View>: View {
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    let first: First
    let second: Second

    init(@ViewBuilder first: () -> First, @ViewBuilder second: () -> Second) {
        self.first = first()
        self.second = second()
    }

    var body: some View {
        Group {
            if dynamicTypeSize.isAccessibilitySize {
                verticalChoices
            } else {
                ViewThatFits(in: .horizontal) {
                    horizontalChoices
                    verticalChoices
                }
            }
        }
        .frame(maxWidth: .infinity)
        .background {
            PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.panel)
                .fill(CarbInTheme.surface)
                .shadow(color: CarbInTheme.line.opacity(0.35), radius: 0, x: 3, y: 4)
        }
        .overlay {
            PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.panel)
                .strokeBorder(CarbInTheme.line, lineWidth: 3)
        }
    }

    private var horizontalChoices: some View {
        HStack(spacing: 0) {
            first.frame(maxWidth: .infinity)
            second.frame(maxWidth: .infinity)
        }
        .overlay {
            CarbInTheme.line.opacity(0.35)
                .frame(width: 1)
                .padding(.vertical, 12)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
    }

    private var verticalChoices: some View {
        VStack(spacing: 0) {
            first.frame(maxWidth: .infinity)
            second.frame(maxWidth: .infinity)
        }
        .overlay {
            CarbInTheme.line.opacity(0.35)
                .frame(height: 1)
                .padding(.horizontal, 14)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
    }
}

struct PixelPhotoChoiceLabel: View {
    let title: LocalizedStringKey
    let kind: PixelKitchenIconKind

    var body: some View {
        HStack(spacing: 8) {
            PixelKitchenIcon(kind: kind)
                .frame(width: 32, height: 32)
            Text(title)
                .font(CarbInTheme.display(.subheadline, size: 16))
                .fixedSize(horizontal: false, vertical: true)
        }
        .foregroundStyle(CarbInTheme.ink)
        .frame(maxWidth: .infinity, minHeight: 56)
        .padding(.horizontal, 8)
        .contentShape(Rectangle())
    }
}

struct MealPlateGraphic: View {
    var showsPen = false

    var body: some View {
        MealMirrorBadge()
            .accessibilityHidden(true)
    }
}

struct MealMirrorBadge: View {
    var showsStars = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var steamIsBright = false

    var body: some View {
        GeometryReader { geometry in
            let side = min(geometry.size.width, geometry.size.height)
            ZStack {
                Canvas { context, size in
                    let pixel = max(7, side / 14)
                    for row in 0...Int(ceil(size.height / pixel)) {
                        for column in 0...Int(ceil(size.width / pixel)) {
                            let color = (row + column).isMultiple(of: 2)
                                ? Color(red: 1, green: 0.88, blue: 0.48)
                                : Color(red: 1, green: 0.77, blue: 0.28)
                            context.fill(
                                Path(CGRect(x: CGFloat(column) * pixel, y: CGFloat(row) * pixel, width: pixel, height: pixel)),
                                with: .color(color)
                            )
                        }
                    }
                }
                .clipShape(Circle())
                .overlay { Circle().stroke(CarbInTheme.line, lineWidth: max(2, side * 0.025)) }
                .shadow(color: CarbInTheme.ink.opacity(0.26), radius: 0, x: 0, y: max(2, side * 0.025))
                .frame(width: side * 0.94, height: side * 0.94)

                Image("CurryMarkCutout")
                    .resizable()
                    .interpolation(.none)
                    .scaledToFit()
                    .frame(width: side, height: side)

                if side >= 120 {
                    SteamPixelHighlight()
                        .frame(width: side, height: side)
                        .opacity(reduceMotion ? 0.5 : (steamIsBright ? 0.72 : 0.25))
                        .animation(
                            reduceMotion ? nil : .easeInOut(duration: 2.8).repeatForever(autoreverses: true),
                            value: steamIsBright
                        )
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }

                if showsStars && side >= 100 {
                    PixelStar()
                        .frame(width: side * 0.075, height: side * 0.075)
                        .offset(x: -side * 0.42, y: -side * 0.35)
                    PixelStar()
                        .frame(width: side * 0.055, height: side * 0.055)
                        .offset(x: side * 0.42, y: -side * 0.25)
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .accessibilityHidden(true)
        .onAppear { steamIsBright = !reduceMotion }
        .onChange(of: reduceMotion) { _, newValue in steamIsBright = !newValue }
    }
}

private struct SteamPixelHighlight: View {
    // These small glints sit inside the three steam wisps of CurryMarkCutout.
    // Keeping them square preserves the original pixel art at large badge sizes.
    private let pixels: [(CGFloat, CGFloat, CGFloat)] = [
        (0.357, 0.102, 0.013), (0.370, 0.153, 0.011),
        (0.495, 0.040, 0.014), (0.485, 0.121, 0.011),
        (0.628, 0.126, 0.013), (0.615, 0.188, 0.011)
    ]

    var body: some View {
        Canvas { context, size in
            let side = min(size.width, size.height)
            for (x, y, width) in pixels {
                context.fill(
                    Path(CGRect(x: x * side, y: y * side, width: width * side, height: width * side)),
                    with: .color(.white)
                )
            }
        }
    }
}

private struct PixelStar: View {
    var body: some View {
        GeometryReader { geometry in
            let unit = geometry.size.width / 5
            ZStack {
                Rectangle().fill(CarbInTheme.line)
                    .frame(width: unit * 1.8, height: geometry.size.height)
                Rectangle().fill(CarbInTheme.line)
                    .frame(width: geometry.size.width, height: unit * 1.8)
                Rectangle().fill(CarbInTheme.surface)
                    .frame(width: unit, height: geometry.size.height)
                Rectangle().fill(CarbInTheme.surface)
                    .frame(width: geometry.size.width, height: unit)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .accessibilityHidden(true)
    }
}

private enum PixelFoodKind: Int, CaseIterable {
    case tomato, carrot, broccoli, rice, egg, fish

    // Hand-plotted 12 × 12 sprites. At the 36 pt ring size each square is
    // exactly 3 pt, keeping the food crisp on both 2× and 3× displays.
    var rows: [String] {
        switch self {
        case .tomato:
            ["....gGGg....", "...ggGGgg...", "...kggggk...", "..krrrrrrk..",
             ".kRrRrrrrRk.", ".kRrhrrrrRk.", "kRrhhrrrrrRk", "kRrrrrrrrrRk",
             ".kRrrrrrrRk.", ".kRrrrrrrRk.", "..kRRRRRRk..", "...kkkkkk..."]
        case .carrot:
            ["...g.g.g....", "..gGgGgGg...", "...gGGGg....", "....gGg.....",
             "...kkkkkk...", "..kOoOoOok..", "..koooooOk..", "...kooooOk..",
             "....koooOk..", ".....kooOk..", "......kook..", ".......kk..."]
        case .broccoli:
            ["...kk..kk...", "..kGgkkGgk..", ".kGgGGgGGgk.", "kGgGGgGGGgGk",
             "kggGGGGGGggk", ".kggGGGGggk.", "..kkgGGgkk..", "...kggggk...",
             "....kttk....", "...kttttk...", "...kttttk...", "....kkkk...."]
        case .rice:
            [".....kkkk...", "...kkwwwwkk.", "..kwwWwwWwwk", ".kwwwwwwwwk.",
             "kwwWwwwWwwwk", ".kkkkkkkkkk.", ".kbbbbbbbbk.", "..kBbbbbBk..",
             "...kBBBBk...", "....kkkk....", "............", "............"]
        case .egg:
            ["............", "..kkk.......", ".kwwWkkk....", "kwwwwwwwkk..",
             "kwwwyyywwwk.", "kwwyYYYywwk.", ".kwwYhYywwk.", "..kwwyyywwwk",
             "...kwwwwwwk.", "....kkkkkk..", "............", "............"]
        case .fish:
            [".....kk...kk", "....kUUk.kUk", "..kkUuUUkkUk", ".kUUuuuuUUk.",
            "kUekUuuuuUUk", "kUuuUuuuuUUk", ".kUUuuuuUUk.", "..kkUuUUkkUk",
             "....kUUk.kUk", ".....kk...kk", "............", "............"]
        }
    }
}

private struct PixelFoodGlyph: View {
    let kind: PixelFoodKind

    var body: some View {
        Canvas { context, size in
            let rows = kind.rows
            let pixel = min(size.width, size.height) / 12
            for (y, row) in rows.enumerated() {
                for (x, symbol) in row.enumerated() where symbol != "." {
                    context.fill(
                        Path(CGRect(x: CGFloat(x) * pixel, y: CGFloat(y) * pixel, width: pixel, height: pixel)),
                        with: .color(color(for: symbol))
                    )
                }
            }
        }
        .accessibilityHidden(true)
    }

    private func color(for symbol: Character) -> Color {
        switch symbol {
        case "k": Color(red: 0.196, green: 0.118, blue: 0.165)
        case "g": Color(red: 0.094, green: 0.459, blue: 0.247)
        case "G": Color(red: 0.333, green: 0.733, blue: 0.369)
        case "r": Color(red: 0.902, green: 0.271, blue: 0.306)
        case "R": Color(red: 0.686, green: 0.184, blue: 0.227)
        case "h": Color(red: 1.000, green: 0.969, blue: 0.769)
        case "o": Color(red: 0.961, green: 0.498, blue: 0.161)
        case "O": Color(red: 1.000, green: 0.682, blue: 0.243)
        case "t": Color(red: 0.573, green: 0.733, blue: 0.388)
        case "w": Color(red: 1.000, green: 0.980, blue: 0.898)
        case "W": Color(red: 0.871, green: 0.820, blue: 0.686)
        case "b": Color(red: 0.886, green: 0.361, blue: 0.353)
        case "B": Color(red: 0.616, green: 0.216, blue: 0.255)
        case "y": Color(red: 0.929, green: 0.620, blue: 0.125)
        case "Y": Color(red: 1.000, green: 0.796, blue: 0.243)
        case "u": Color(red: 0.196, green: 0.510, blue: 0.651)
        case "U": Color(red: 0.380, green: 0.725, blue: 0.780)
        case "e": Color(red: 1.000, green: 1.000, blue: 1.000)
        default: .clear
        }
    }
}

struct FoodOrbitRing: View {
    var diameter: CGFloat = 286
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isRotating = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(CarbInTheme.actionInk.opacity(0.85), style: StrokeStyle(lineWidth: 3, dash: [8, 9]))
                .frame(width: diameter - 10, height: diameter - 10)

            MealMirrorBadge()
                .frame(width: diameter * 0.76, height: diameter * 0.76)

            ZStack {
                ForEach(PixelFoodKind.allCases, id: \.rawValue) { food in
                    let angle = Double(food.rawValue) * 2 * Double.pi / Double(PixelFoodKind.allCases.count)
                    PixelFoodGlyph(kind: food)
                        .frame(width: 36, height: 36)
                        .padding(3)
                        .background(CarbInTheme.actionInk, in: Circle())
                        .overlay {
                            Circle().stroke(Color(red: 0.196, green: 0.118, blue: 0.165), lineWidth: 2)
                        }
                        .rotationEffect(.degrees(isRotating && !reduceMotion ? -360 : 0))
                        .offset(x: CGFloat(cos(angle)) * (diameter / 2 - 5), y: CGFloat(sin(angle)) * (diameter / 2 - 5))
                }
            }
            .frame(width: diameter, height: diameter)
            .rotationEffect(.degrees(isRotating && !reduceMotion ? 360 : 0))
            .animation(reduceMotion ? nil : .linear(duration: 14).repeatForever(autoreverses: false), value: isRotating)
        }
        .frame(width: diameter, height: diameter)
        .onAppear { isRotating = !reduceMotion }
        .onChange(of: reduceMotion) { _, newValue in isRotating = !newValue }
        .accessibilityHidden(true)
    }
}

struct KitchenLoadingArtwork: View {
    let diameter: CGFloat

    var body: some View {
        FoodOrbitRing(diameter: diameter)
            .frame(width: diameter, height: diameter)
            .accessibilityHidden(true)
    }
}

struct PixelCornerFrame: View {
    var color: Color = CarbInTheme.tomato
    var inset: CGFloat = 10
    var arm: CGFloat = 16
    var thickness: CGFloat = 3

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                pixelCorner
                Spacer(minLength: 0)
                pixelCorner.rotationEffect(.degrees(90))
            }
            Spacer(minLength: 0)
            HStack(spacing: 0) {
                pixelCorner.rotationEffect(.degrees(270))
                Spacer(minLength: 0)
                pixelCorner.rotationEffect(.degrees(180))
            }
        }
        .padding(inset)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private var pixelCorner: some View {
        ZStack(alignment: .topLeading) {
            Rectangle().fill(color).frame(width: arm, height: thickness)
            Rectangle().fill(color).frame(width: thickness, height: arm)
        }
    }
}

struct PixelDivider: View {
    var color: Color = CarbInTheme.tomato

    var body: some View {
        HStack(spacing: 3) {
            ForEach(0..<15, id: \.self) { index in
                Rectangle()
                    .fill(index.isMultiple(of: 4) ? color : CarbInTheme.line.opacity(0.55))
                    .frame(width: index.isMultiple(of: 4) ? 11 : 5, height: 3)
            }
        }
        .frame(maxWidth: 210, alignment: .leading)
        .accessibilityHidden(true)
    }
}

struct StepRail: View {
    let current: Int
    @EnvironmentObject private var localization: LocalizationStore

    var body: some View {
        HStack(spacing: 6) {
            ForEach(1...3, id: \.self) { step in
                Rectangle()
                    .fill(step < current ? CarbInTheme.basilAction :
                          (step == current ? CarbInTheme.tomatoAction : CarbInTheme.inset))
                    .frame(maxWidth: .infinity, minHeight: 7, maxHeight: 7)
                    .overlay { Rectangle().stroke(CarbInTheme.line.opacity(0.6), lineWidth: 1) }
            }
            Text(verbatim: "\(current)/3")
                .font(CarbInTheme.brand(.caption1, size: 13))
                .foregroundStyle(CarbInTheme.ink)
                .fixedSize()
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(localization.text(["STEP 1 OF 3", "STEP 2 OF 3", "STEP 3 OF 3"][max(0, min(current - 1, 2))]))
    }
}

struct SafetyRail: View {
    let title: LocalizedStringKey
    let detail: LocalizedStringKey
    var symbol = "exclamationmark.shield.fill"

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Rectangle()
                .fill(CarbInTheme.tomato)
                .frame(width: 5)
            Image(systemName: symbol)
                .foregroundStyle(CarbInTheme.tomato)
                .frame(width: 24, height: 24)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(CarbInTheme.display(.subheadline, size: 15))
                    .foregroundStyle(CarbInTheme.ink)
                Text(detail)
                    .font(CarbInTheme.reading(.footnote, size: 13))
                    .foregroundStyle(CarbInTheme.mutedInk)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 12)
        .padding(.trailing, 12)
        .background(CarbInTheme.ticket, in: PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card))
        .clipShape(PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card))
        .overlay {
            PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.card)
                .strokeBorder(CarbInTheme.ink.opacity(0.78), lineWidth: 2)
        }
    }
}

private struct KitchenNavigationTitle: ViewModifier {
    let title: LocalizedStringKey
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.colorScheme) private var colorScheme

    func body(content: Content) -> some View {
        content.navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text(title)
                        // Every screen also has a full-size heading in its body.
                        // Keep the compact navigation cue readable at AX sizes.
                        .font(dynamicTypeSize.isAccessibilitySize
                            ? .system(size: 18, weight: .bold)
                            : CarbInTheme.display(.headline, size: 18))
                        .foregroundStyle(CarbInTheme.navigationInk(for: colorScheme))
                        .lineLimit(dynamicTypeSize.isAccessibilitySize ? 1 : 2)
                        .minimumScaleFactor(0.8)
                }
            }
            .toolbarBackground(CarbInTheme.canvas, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
    }
}

extension View {
    func kitchenNavigationTitle(_ title: LocalizedStringKey) -> some View {
        modifier(KitchenNavigationTitle(title: title))
    }

    func workbenchSurface(inset: CGFloat = 18, fill: Color = CarbInTheme.surface) -> some View {
        self.padding(inset)
            .background {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.panel)
                    .fill(fill)
                    .shadow(color: CarbInTheme.line.opacity(0.48), radius: 0, x: 4, y: 5)
            }
            .overlay {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.panel)
                    .strokeBorder(CarbInTheme.line, lineWidth: 3)
            }
    }

    func mealTicket(inset: CGFloat = 18) -> some View {
        self.padding(inset)
            .background {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.panel)
                    .fill(CarbInTheme.surface)
                    .shadow(color: CarbInTheme.line.opacity(0.48), radius: 0, x: 4, y: 5)
            }
            .overlay {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.panel)
                    .strokeBorder(CarbInTheme.line, lineWidth: 3)
            }
    }

    func insetControlGroup(inset: CGFloat = 14) -> some View {
        self.padding(inset)
            .background(CarbInTheme.butter.opacity(0.20), in: PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.field))
            .overlay {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.field)
                    .strokeBorder(CarbInTheme.line.opacity(0.72), lineWidth: 1.5)
            }
    }

    func pixelInputField() -> some View {
        self.padding(.horizontal, 12)
            .padding(.vertical, 12)
            .frame(minHeight: 52)
            .background(CarbInTheme.surface, in: PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.field))
            .overlay {
                PixelRoundedRectangle(cornerRadius: PixelSurfaceTier.field)
                    .strokeBorder(CarbInTheme.line, lineWidth: 2)
            }
    }

    // Legacy call sites now receive the distinctive ticket surface rather than
    // the former universal 24-point floating card.
    func mirrorCard(inset: CGFloat = 18) -> some View {
        mealTicket(inset: inset)
    }

    func pixelCorners(color: Color = CarbInTheme.tomato, inset: CGFloat = 10) -> some View {
        overlay { PixelCornerFrame(color: color, inset: inset) }
    }
}
